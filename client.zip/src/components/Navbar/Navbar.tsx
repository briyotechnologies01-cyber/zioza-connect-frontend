import Image from "next/image";

const navigationItems = ["Features", "Integrations", "Pricing", "Resources"];

export default function Navbar() {
    return (
        <header className="absolute inset-x-0 top-0 z-30 flex h-[76px] items-center justify-between gap-8 px-[120px] py-2.5 max-[1200px]:px-10 max-[900px]:h-[68px] max-[900px]:px-[22px]">
            <a className="inline-flex items-center" href="#top" aria-label="Zioza home">
                <Image src="/zioza-logo.png" alt="Zioza" width={153} height={45} className="h-auto w-[153px] max-[520px]:w-[110px]" priority />
            </a>

            <nav className="ml-auto mr-[clamp(20px,4vw,78px)] flex items-center gap-[clamp(24px,3vw,58px)] max-[900px]:hidden" aria-label="Primary navigation">
                {navigationItems.map((item) => (
                    <a className="whitespace-nowrap text-sm font-semibold" href={`#${item.toLowerCase()}`} key={item}>
                        {item}
                        {(item === "Features" || item === "Resources") && (
                            <span className="ml-2 inline-block translate-y-[-1px] text-[12px] leading-none font-bold" aria-hidden="true">
                                v
                            </span>
                        )}
                    </a>
                ))}
            </nav>

            <div className="flex items-center gap-6 max-[900px]:gap-3.5">
                <a className="whitespace-nowrap text-sm font-semibold max-[900px]:hidden" href="#login">
                    Login
                </a>
                <a className="inline-flex min-h-12 items-center justify-center gap-3 rounded-[28px] bg-[#4b50ff] px-[25px] text-sm font-bold text-white transition hover:-translate-y-0.5 hover:shadow-[0_10px_24px_rgba(75,80,255,0.2)] max-[900px]:min-h-[42px] max-[900px]:px-[17px]" href="#get-started">
                    Get Started Free <span aria-hidden="true">-&gt;</span>
                </a>
            </div>
        </header>
    );
}