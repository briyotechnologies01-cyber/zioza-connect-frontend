import Image from "next/image";

export default function HeroSection() {
    return (
        <main className="relative min-h-[min(800px,100vh)] overflow-hidden bg-[#f6fbfe] max-[900px]:min-h-0" id="top">
            {/* Background shade image — matches Figma: right side, behind inbox mockup */}
            <div
                className="pointer-events-none absolute z-0
                            right-[-6%] top-[-7%] h-[110%] w-[62%]
                            max-[1200px]:w-[75%]
                            max-[900px]:right-[-25%] max-[900px]:top-[-5%] max-[900px]:h-[65%] max-[900px]:w-[95%]"
            >
                <Image
                    src="/bg-shade.png"
                    alt=""
                    fill
                    priority
                    className="object-contain object-right-top opacity-70"
                    sizes="(max-width: 900px) 95vw, 62vw"
                />
            </div>

            <div className="relative z-10 grid min-h-[min(800px,100vh)] grid-cols-[minmax(0,0.94fr)_minmax(500px,1.06fr)] items-center gap-[30px] px-[120px] pb-[30px] pt-[92px] max-[1200px]:px-10 max-[900px]:min-h-0 max-[900px]:grid-cols-1 max-[900px]:px-[22px] max-[900px]:pb-[42px] max-[900px]:pt-[120px]">

                {/* Left: text content */}
                <div className="max-w-[684px] max-[900px]:mx-auto max-[900px]:text-center">
                    <p className="mb-[22px] inline-flex rounded-[20px] border border-[#4b50ff] px-3.5 py-[7px] text-xs font-semibold text-[#4b50ff]">
                        AI-Powered Omnichannel Platform
                    </p>
                    <h1 className="m-0 text-[clamp(36px,3.4vw,62px)] font-bold leading-[1.08] tracking-[-1.7px] max-[520px]:text-[37px]">
                        One Platform.
                        <br />
                        Every Conversation.
                        <br />
                        <span className="bg-gradient-to-r from-[#4551ff] to-[#a348f5] bg-clip-text text-transparent">
                            Smarter Customer Engagement.
                        </span>
                    </h1>
                    <p className="mb-[30px] mt-[26px] max-w-[620px] text-base leading-[1.55] text-[#666b77] max-[900px]:mx-auto max-[520px]:text-sm">
                        Manage all your messages, automate conversations, create engaging content, and
                        turn customer interactions into lasting relationships - all in one place.
                    </p>
                    <div className="flex items-center gap-6 max-[900px]:justify-center max-[520px]:flex-col max-[520px]:items-stretch">
                        <a
                            className="inline-flex min-h-[50px] items-center justify-center gap-3 rounded-[28px] bg-[#4b50ff] px-[25px] text-sm font-bold text-white transition hover:-translate-y-0.5 hover:shadow-[0_10px_24px_rgba(75,80,255,0.2)] max-[520px]:w-full"
                            href="#get-started"
                        >
                            Get Started Free <span aria-hidden="true">-&gt;</span>
                        </a>

                        <a
                            className="inline-flex min-h-[50px] items-center justify-center gap-3 rounded-[28px] border border-[#4b50ff] px-[25px] text-sm font-bold text-[#4b50ff] transition hover:-translate-y-0.5 hover:shadow-[0_10px_24px_rgba(75,80,255,0.2)] max-[520px]:w-full"
                            href="#demo"
                        >
                            Book A Demo
                        </a>
                    </div>
                </div>

                {/* Right: unified inbox mockup (icons already included in this image) */}
                <div className="flex min-w-0 items-center justify-center">
                    <Image
                        src="/Hero/hero-bg-image.png"
                        alt="Zioza unified inbox dashboard"
                        className="relative z-10 h-auto w-[min(830px,100%)] max-w-full object-contain"
                        width={830}
                        height={650}
                        priority
                        sizes="(max-width: 900px) 92vw, 55vw"
                    />
                </div>
            </div>
        </main>
    );
}